package com.example.conexion_bluetooth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class ConexionActivity extends AppCompatActivity {

    ImageView btnOff, btnOn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conexion);

        btnOn = (ImageView) findViewById(R.id.idButtonOn);
        btnOff = (ImageView) findViewById(R.id.idButtonOff);

        btnOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText( getApplicationContext(), "ENCENDIDO", Toast.LENGTH_SHORT).show();
            }
        });

        btnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText( getApplicationContext(), "APAGADO", Toast.LENGTH_SHORT).show();
            }
        });
    }
}